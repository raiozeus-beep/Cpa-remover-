package com.example.c2paremover;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * Escolhe uma foto, redesenha os pixels em um novo arquivo e salva em Pictures/SemC2PA.
 *
 * Como funciona: o C2PA (Content Credentials) fica em metadados do arquivo (JUMBF/APP11
 * no JPEG, chunk caBX no PNG, etc.). Ao decodificar para Bitmap e recodificar, apenas os
 * pixels são mantidos: C2PA, EXIF, XMP, GPS e miniaturas ficam para trás.
 */
public class MainActivity extends Activity {

    private static final int REQ_PICK = 1;

    private ImageView preview;
    private TextView status;
    private Button saveBtn;
    private Bitmap current;
    private String currentName = "foto";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();

        Intent intent = getIntent();
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (uri != null) loadImage(uri);
        }
    }

    private void buildUi() {
        int pad = dp(16);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Remover C2PA da foto");
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        Button pick = new Button(this);
        pick.setText("Adicionar foto");
        pick.setOnClickListener(v -> pickImage());
        root.addView(pick, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        pp.topMargin = pad;
        pp.bottomMargin = pad;
        root.addView(preview, pp);

        status = new TextView(this);
        status.setGravity(Gravity.CENTER);
        status.setText("Nenhuma foto selecionada.");
        root.addView(status);

        saveBtn = new Button(this);
        saveBtn.setText("Remover C2PA e salvar");
        saveBtn.setEnabled(false);
        saveBtn.setOnClickListener(v -> saveClean());
        root.addView(saveBtn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(i, "Escolher foto"), REQ_PICK);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null) {
            loadImage(data.getData());
        }
    }

    private void loadImage(Uri uri) {
        new Thread(() -> {
            try {
                Bitmap bmp;
                int orientation = ExifInterface.ORIENTATION_NORMAL;

                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    ExifInterface exif = new ExifInterface(in);
                    orientation = exif.getAttributeInt(
                            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                }
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    bmp = BitmapFactory.decodeStream(in);
                }
                if (bmp == null) throw new IllegalStateException("Formato de imagem não suportado");

                bmp = applyOrientation(bmp, orientation);
                final Bitmap result = bmp;
                runOnUiThread(() -> {
                    current = result;
                    currentName = "foto_" + System.currentTimeMillis();
                    preview.setImageBitmap(result);
                    status.setText(result.getWidth() + " × " + result.getHeight() + " px");
                    saveBtn.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this,
                        "Erro ao abrir: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    /** Aplica a rotação do EXIF nos pixels, já que o EXIF será descartado. */
    private static Bitmap applyOrientation(Bitmap src, int orientation) {
        Matrix m = new Matrix();
        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90: m.postRotate(90); break;
            case ExifInterface.ORIENTATION_ROTATE_180: m.postRotate(180); break;
            case ExifInterface.ORIENTATION_ROTATE_270: m.postRotate(270); break;
            case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: m.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_FLIP_VERTICAL: m.postScale(1, -1); break;
            case ExifInterface.ORIENTATION_TRANSPOSE: m.postRotate(90); m.postScale(-1, 1); break;
            case ExifInterface.ORIENTATION_TRANSVERSE: m.postRotate(270); m.postScale(-1, 1); break;
            default: return src;
        }
        Bitmap out = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
        if (out != src) src.recycle();
        return out;
    }

    private void saveClean() {
        if (current == null) return;
        saveBtn.setEnabled(false);
        final Bitmap bmp = current;
        final String name = currentName;

        new Thread(() -> {
            try {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, name + ".jpg");
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SemC2PA");
                cv.put(MediaStore.Images.Media.IS_PENDING, 1);

                Uri out = getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                if (out == null) throw new IllegalStateException("Não foi possível criar o arquivo");

                try (OutputStream os = getContentResolver().openOutputStream(out)) {
                    // Só pixels: nenhum metadado é escrito.
                    bmp.compress(Bitmap.CompressFormat.JPEG, 95, os);
                }
                cv.clear();
                cv.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(out, cv, null, null);

                runOnUiThread(() -> {
                    status.setText("Salvo em Pictures/SemC2PA ✔");
                    Toast.makeText(this, "Foto salva sem C2PA", Toast.LENGTH_SHORT).show();
                    saveBtn.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Erro ao salvar: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                    saveBtn.setEnabled(true);
                });
            }
        }).start();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
