# Remover C2PA (Android)

App simples: escolhe uma foto, remove C2PA/EXIF/XMP/GPS recodificando só os pixels
e salva em `Pictures/SemC2PA`. Também aparece no menu "Compartilhar" da galeria.

## Como gerar o APK

**Opção A — Android Studio:** File > Open nesta pasta, aguarde o sync e use
Build > Build APK(s). Arquivo em `app/build/outputs/apk/release/`.

**Opção B — Linha de comando** (com Android SDK e Gradle 8.7+ instalados):

    gradle assembleRelease

**Opção C — GitHub Actions:** envie esta pasta para um repositório; o workflow em
`.github/workflows/build.yml` gera o APK como artefato.

## Observações
- Android 10+ (minSdk 29). Saída em JPEG qualidade 95 (há recompressão).
- O APK sai assinado com a chave de debug, bom para uso pessoal.
